"""
This maps the offshore wind spatial data inputs to the marine energy datasets.

Original offshore wind data is generated using the reVX tool:
https://github.com/NREL/reVX/blob/main/reVX/offshore/offshore_inputs_cli.py
"""

import numpy as np
import pandas as pd
from rex import WaveResource
from scipy.spatial import cKDTree
import matplotlib.pyplot as plt

# only export certain columns that are used in the marine models
columns = ['config', 'latitude', 'longitude', 'depth', 'dist_s_to_l']

fp_offshore_wind = '/shared-projects/rev/exclusions/offshore_inputs.csv'
fp_wave_res = '/datasets/US_wave/v1.0.0/Atlantic/Atlantic_wave_1979.h5'
fp_out = './atlantic_wave_spatial_inputs.csv'

base_data = pd.read_csv(fp_offshore_wind, index_col=0)
with WaveResource(fp_wave_res) as res:
    meta = res.meta

labels = ['latitude', 'longitude']
tree = cKDTree(base_data[labels])
d, i = tree.query(meta[labels])

wave_data = base_data.iloc[i, :]
wave_data.index = meta.index.values
wave_data.index.name = 'gid'
wave_data['latitude'] = meta['latitude']
wave_data['longitude'] = meta['longitude']
wave_data['config'] = 'wec'
wave_data[columns].to_csv(fp_out)

plot_df = wave_data.iloc[slice(None, None, 1)]
plt.scatter(x=plot_df.longitude, y=plot_df.latitude, c=plot_df.depth, s=1)
plt.savefig(fp_out.replace('.csv', '_depth.png'), dpi=600)
