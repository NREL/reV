"""
Search wave resource for NaN values and make project points from points with no
NaN values. Unfortunately the NaN values appear to be randomly distributed in
the timeseries data and so you need to load the full dataset for every year in
the analysis.
"""

import pandas as pd
import numpy as np
from rex import WaveResource

years = range(1979, 2011)
fp_res = '/datasets/US_wave/v1.0.0/West_Coast/West_Coast_wave_{}.h5'
fp_out = './pacific_project_points_wave.csv'

nan = None
for year in years:
    print('Running year {}'.format(year))
    with WaveResource(fp_res.format(year)) as res:
        meta = res.meta
        print('loading period')
        period = res['energy_period']
        nan_p = np.isnan(period).any(axis=0)
        del period
        print('loading height')
        height = res['significant_wave_height']
        nan_h = np.isnan(height).any(axis=0)
        del height

    if nan is None:
        nan = nan_p | nan_h
    else:
        nan = nan | nan_p | nan_h

    print('Current total for year {} is {} NaN values'.format(year, nan.sum()))

good = np.where(~nan)[0]
print('Found {} nan values out of {}'.format(nan.sum(), len(nan)))

project_points = pd.DataFrame({'gid': good, 'config': 'wec'})
project_points.to_csv(fp_out, index=False)
print('Saved: ', fp_out)
